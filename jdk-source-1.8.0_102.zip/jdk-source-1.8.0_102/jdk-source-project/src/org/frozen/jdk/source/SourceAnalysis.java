package org.frozen.jdk.source;

import java.util.HashMap;
import java.util.Map;

public class SourceAnalysis {

    public static void main(String[] args) {
        Map<String, String> hashMap = new HashMap<String, String>();
        hashMap.put("a", "A");
    }
}
